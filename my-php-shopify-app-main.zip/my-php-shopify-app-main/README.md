# My PHP Shopify App

This is a custom PHP app that connects to a Shopify store using the Storefront API.

- Uses PHP 8.1
- Hosted on Azure App Service
- Connected via GitHub Actions

## Shopify Domain
sduigc-r1.myshopify.com
